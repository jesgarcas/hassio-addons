# Changelog

## 1.2.0

- Upgrade to wyoming 1.5.3
- Run tests over more Python versions

## 1.1.0

- Add tests and Github actions
- Add `--log-format` argument
- Add `--version` argument

## 1.0.1

- Try to fix memory leak by caching detectors

## 1.0.0

- Initial release
